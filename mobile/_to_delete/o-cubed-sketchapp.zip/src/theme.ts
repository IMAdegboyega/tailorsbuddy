/**
 * Couture theme tokens for O_Cubed / Atelier Vaux.
 * Ported from the Claude Design prototype (Atelier Vaux.dc.html).
 */

export const colors = {
  // Backgrounds
  black: '#0C0A08',
  bg: '#16120E',
  bgRail: '#100D0A',
  bgPanel: '#100D0A',
  bgCanvas: '#1A1712',
  bgCard: '#1B1712',

  // Gold accent
  gold: '#BE8A5A',
  goldBright: '#D9A46A',

  // Text / cream
  cream: '#E9E1D2',
  creamBright: '#EDE6D8',

  // Croquis paper
  paperTop: '#faf7f0',
  paperBottom: '#efe8db',
  sketchLight: '#f6f2ea',
  sketchDark: '#e9e2d5',
} as const;

/** Alpha helpers over the gold accent (rgba(190,138,90, a)). */
export const gold = (a: number) => `rgba(190,138,90,${a})`;
/** Alpha helpers over the cream text (rgba(233,225,210, a)). */
export const cream = (a: number) => `rgba(233,225,210,${a})`;

export const fonts = {
  // Serif display face
  serif: 'CormorantGaramond_500Medium',
  serifRegular: 'CormorantGaramond_400Regular',
  serifItalic: 'CormorantGaramond_500Medium_Italic',
  serifSemiBold: 'CormorantGaramond_600SemiBold',
  // Sans body face
  sans: 'Jost_400Regular',
  sansLight: 'Jost_300Light',
  sansMedium: 'Jost_500Medium',
  sansSemiBold: 'Jost_600SemiBold',
} as const;

export type Theme = typeof colors;
