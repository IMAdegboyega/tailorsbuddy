import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { colors, fonts, gold } from '../theme';
import { Icon, IconName } from './Icon';
import { Screen, useApp } from '../state/AppContext';

interface RailItem {
  name: IconName;
  active: boolean;
  onPress: () => void;
}

/** The slim left navigation rail that persists across the shell screens. */
export function Rail() {
  const { screen, goClients, goPricing, goSettings } = useApp();

  const shellClients: Screen[] = ['clients', 'detail', 'newdesign'];
  const items: RailItem[] = [
    { name: 'users', active: shellClients.includes(screen), onPress: goClients },
    { name: 'dollar', active: screen === 'pricing', onPress: goPricing },
    { name: 'settings', active: screen === 'settings', onPress: goSettings },
  ];

  return (
    <View style={styles.rail}>
      <View style={styles.logo}>
        <Text style={styles.logoMark}>O³</Text>
      </View>
      <View style={styles.items}>
        {items.map((it) => (
          <Pressable
            key={it.name}
            onPress={it.onPress}
            style={({ pressed }) => [
              styles.item,
              {
                backgroundColor: it.active ? gold(0.12) : 'transparent',
                borderLeftColor: it.active ? colors.gold : 'transparent',
              },
              pressed && !it.active && { backgroundColor: gold(0.06) },
            ]}
          >
            <Icon
              name={it.name}
              size={21}
              color={it.active ? colors.goldBright : gold(0.55)}
            />
          </Pressable>
        ))}
      </View>
      <View style={styles.avatar}>
        <Text style={styles.avatarText}>SV</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  rail: {
    width: 78,
    flex: 0,
    backgroundColor: colors.bgRail,
    borderRightWidth: 1,
    borderRightColor: gold(0.13),
    alignItems: 'center',
    paddingVertical: 22,
  },
  logo: {
    width: 42,
    height: 42,
    borderWidth: 1,
    borderColor: gold(0.45),
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 34,
  },
  logoMark: {
    fontFamily: fonts.serifItalic,
    fontSize: 17,
    color: colors.gold,
  },
  items: {
    flex: 1,
    gap: 6,
    alignItems: 'center',
  },
  item: {
    width: 46,
    height: 46,
    borderRadius: 4,
    alignItems: 'center',
    justifyContent: 'center',
    borderLeftWidth: 2,
  },
  avatar: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: '#201b12',
    borderWidth: 1,
    borderColor: gold(0.3),
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontFamily: fonts.serif,
    fontSize: 13,
    color: colors.gold,
  },
});
