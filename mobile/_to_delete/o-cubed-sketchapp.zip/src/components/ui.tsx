import React from 'react';
import {
  Pressable,
  StyleProp,
  StyleSheet,
  Text,
  TextInput,
  TextInputProps,
  TextStyle,
  View,
  ViewStyle,
} from 'react-native';

import { colors, cream, fonts, gold } from '../theme';
import { Icon, IconName } from './Icon';

/** Filled gold call-to-action button with optional leading/trailing icon. */
export function PrimaryButton({
  label,
  onPress,
  icon,
  trailingIcon,
  style,
}: {
  label: string;
  onPress?: () => void;
  icon?: IconName;
  trailingIcon?: IconName;
  style?: StyleProp<ViewStyle>;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.primary,
        { backgroundColor: pressed ? colors.goldBright : colors.gold },
        style,
      ]}
    >
      {icon && <Icon name={icon} size={14} color={colors.bg} strokeWidth={1.7} />}
      <Text style={styles.primaryLabel}>{label}</Text>
      {trailingIcon && <Icon name={trailingIcon} size={16} color={colors.bg} strokeWidth={1.8} />}
    </Pressable>
  );
}

/** Bordered / ghost gold button. */
export function OutlineButton({
  label,
  onPress,
  icon,
  style,
}: {
  label: string;
  onPress?: () => void;
  icon?: IconName;
  style?: StyleProp<ViewStyle>;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.outline,
        { backgroundColor: pressed ? gold(0.1) : 'transparent' },
        style,
      ]}
    >
      {icon && <Icon name={icon} size={14} color={colors.gold} strokeWidth={1.6} />}
      <Text style={styles.outlineLabel}>{label}</Text>
    </Pressable>
  );
}

/** A back link ("‹ ALL CLIENTS") used at the top of detail-style screens. */
export function BackLink({ label, onPress }: { label: string; onPress?: () => void }) {
  return (
    <Pressable onPress={onPress} style={styles.backLink} hitSlop={8}>
      <Icon name="chevronLeft" size={13} color={gold(0.7)} strokeWidth={1.6} />
      <Text style={styles.backLinkLabel}>{label}</Text>
    </Pressable>
  );
}

/** An eyebrow / kicker label (small, letter-spaced, gold). */
export function Kicker({ children, style }: { children: React.ReactNode; style?: StyleProp<TextStyle> }) {
  return <Text style={[styles.kicker, style]}>{children}</Text>;
}

/** Serif display heading. */
export function Display({
  children,
  size = 34,
  style,
}: {
  children: React.ReactNode;
  size?: number;
  style?: StyleProp<TextStyle>;
}) {
  return <Text style={[styles.display, { fontSize: size }, style]}>{children}</Text>;
}

/** Underlined text field with a small label, matching the couture forms. */
export function Field({
  label,
  style,
  ...props
}: TextInputProps & { label?: string; style?: StyleProp<ViewStyle> }) {
  return (
    <View style={[styles.field, style]}>
      {label && <Text style={styles.fieldLabel}>{label}</Text>}
      <TextInput
        placeholderTextColor={cream(0.32)}
        selectionColor={colors.gold}
        style={styles.fieldInput}
        {...props}
      />
    </View>
  );
}

/** The circular O³ monogram used across brand surfaces. */
export function Monogram({ size = 42, fontSize = 17 }: { size?: number; fontSize?: number }) {
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        borderWidth: 1,
        borderColor: gold(0.45),
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Text style={{ fontFamily: fonts.serifItalic, fontSize, color: colors.gold }}>O³</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  primary: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    paddingVertical: 13,
    paddingHorizontal: 20,
    borderRadius: 2,
  },
  primaryLabel: {
    color: colors.bg,
    fontSize: 11,
    letterSpacing: 2,
    fontFamily: fonts.sansSemiBold,
  },
  outline: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    paddingVertical: 11,
    paddingHorizontal: 18,
    borderRadius: 2,
    borderWidth: 1,
    borderColor: gold(0.4),
  },
  outlineLabel: {
    color: colors.gold,
    fontSize: 11,
    letterSpacing: 2,
    fontFamily: fonts.sansMedium,
  },
  backLink: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
  },
  backLinkLabel: {
    color: gold(0.7),
    fontSize: 11,
    letterSpacing: 2,
    fontFamily: fonts.sans,
  },
  kicker: {
    fontSize: 11,
    letterSpacing: 3,
    color: gold(0.7),
    fontFamily: fonts.sans,
  },
  display: {
    fontFamily: fonts.serif,
    color: colors.creamBright,
    lineHeight: undefined,
  },
  field: {
    gap: 6,
  },
  fieldLabel: {
    fontSize: 11,
    color: cream(0.5),
    letterSpacing: 0.5,
    fontFamily: fonts.sans,
  },
  fieldInput: {
    borderBottomWidth: 1,
    borderBottomColor: gold(0.28),
    color: colors.cream,
    fontSize: 14,
    paddingVertical: 8,
    fontFamily: fonts.sans,
  },
});
