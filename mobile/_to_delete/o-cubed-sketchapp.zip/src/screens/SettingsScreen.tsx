import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';

import { colors, cream, fonts, gold } from '../theme';
import { Field } from '../components/ui';
import { useApp } from '../state/AppContext';

export function SettingsScreen() {
  const { goPricing } = useApp();
  const [name, setName] = useState('Séverine Vaux');
  const [atelier, setAtelier] = useState('O_Cubed');

  return (
    <ScrollView contentContainerStyle={styles.body} showsVerticalScrollIndicator={false}>
      <Text style={styles.kicker}>ATELIER</Text>
      <Text style={styles.title}>Settings</Text>

      <View style={styles.stack}>
        {/* profile */}
        <View style={styles.card}>
          <Text style={styles.cardLabel}>PROFILE</Text>
          <View style={styles.profileRow}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>SV</Text>
            </View>
            <View style={styles.profileFields}>
              <Field label="Name" value={name} onChangeText={setName} style={styles.col} />
              <Field label="Atelier" value={atelier} onChangeText={setAtelier} style={styles.col} />
            </View>
          </View>
        </View>

        {/* brand logo */}
        <View style={styles.card}>
          <Text style={styles.cardLabel}>BRAND LOGO — FOR EXPORTS</Text>
          <View style={styles.logoRow}>
            <View style={styles.logoBox}>
              <Text style={styles.logoMark}>O³</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Pressable style={({ pressed }) => [styles.upload, pressed && { backgroundColor: gold(0.08) }]}>
                <Text style={styles.uploadLabel}>UPLOAD LOGO</Text>
              </Pressable>
              <Text style={styles.logoNote}>PNG or SVG · appears on every spec sheet</Text>
            </View>
          </View>
        </View>

        {/* plan status */}
        <View style={[styles.card, styles.planCard]}>
          <View>
            <Text style={styles.cardLabel}>PLAN STATUS</Text>
            <Text style={styles.planValue}>Yearly · Active</Text>
            <Text style={styles.planRenew}>Renews 14 March 2027</Text>
          </View>
          <Pressable
            onPress={goPricing}
            style={({ pressed }) => [styles.manage, pressed && { backgroundColor: gold(0.08) }]}
          >
            <Text style={styles.manageLabel}>MANAGE PLAN</Text>
          </Pressable>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  body: { padding: 34, paddingBottom: 60 },
  kicker: { fontSize: 11, letterSpacing: 3, color: gold(0.7), marginBottom: 8, fontFamily: fonts.sans },
  title: { fontFamily: fonts.serif, fontSize: 36, color: colors.creamBright, marginBottom: 30 },
  stack: { maxWidth: 620, gap: 14 },
  card: { borderWidth: 1, borderColor: gold(0.14), borderRadius: 4, padding: 24 },
  cardLabel: { fontSize: 10, letterSpacing: 2, color: gold(0.7), marginBottom: 18, fontFamily: fonts.sans },
  profileRow: { flexDirection: 'row', alignItems: 'center', gap: 18 },
  avatar: {
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: '#221c12',
    borderWidth: 1,
    borderColor: gold(0.32),
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: { fontFamily: fonts.serif, fontSize: 22, color: colors.gold },
  profileFields: { flex: 1, flexDirection: 'row', gap: 16 },
  col: { flex: 1 },
  logoRow: { flexDirection: 'row', alignItems: 'center', gap: 20 },
  logoBox: {
    width: 88,
    height: 88,
    borderWidth: 1,
    borderColor: gold(0.35),
    borderStyle: 'dashed',
    borderRadius: 4,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoMark: { fontFamily: fonts.serifItalic, fontSize: 26, color: colors.gold },
  upload: {
    alignSelf: 'flex-start',
    borderWidth: 1,
    borderColor: gold(0.4),
    paddingVertical: 10,
    paddingHorizontal: 18,
    borderRadius: 2,
  },
  uploadLabel: { color: colors.gold, fontSize: 11, letterSpacing: 2, fontFamily: fonts.sans },
  logoNote: { fontSize: 11, color: cream(0.4), marginTop: 10, fontFamily: fonts.sans },
  planCard: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  planValue: { fontFamily: fonts.serif, fontSize: 20, color: colors.creamBright },
  planRenew: { fontSize: 12, color: cream(0.45), marginTop: 4, fontFamily: fonts.sans },
  manage: {
    borderWidth: 1,
    borderColor: gold(0.4),
    paddingVertical: 10,
    paddingHorizontal: 18,
    borderRadius: 2,
  },
  manageLabel: { color: colors.gold, fontSize: 11, letterSpacing: 2, fontFamily: fonts.sans },
});
