import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

import { colors, cream, fonts, gold } from '../theme';
import { PrimaryButton } from '../components/ui';
import { useApp } from '../state/AppContext';

export function LoginScreen() {
  const { doLogin } = useApp();
  const [email, setEmail] = useState('severine@ocubed.com');
  const [pass, setPass] = useState('0000000000');

  return (
    <LinearGradient colors={['#1A1610', colors.bg]} style={styles.fill}>
      <View style={styles.center}>
        <View style={styles.mono}>
          <Text style={styles.monoMark}>O³</Text>
        </View>
        <Text style={styles.title}>O_CUBED</Text>
        <Text style={styles.tagline}>bespoke · since MCMXCII</Text>

        <View style={styles.form}>
          <TextInput
            value={email}
            onChangeText={setEmail}
            placeholder="Atelier email"
            placeholderTextColor={cream(0.32)}
            autoCapitalize="none"
            keyboardType="email-address"
            selectionColor={colors.gold}
            style={styles.input}
          />
          <TextInput
            value={pass}
            onChangeText={setPass}
            placeholder="Passphrase"
            placeholderTextColor={cream(0.32)}
            secureTextEntry
            selectionColor={colors.gold}
            style={[styles.input, { letterSpacing: 6 }]}
          />
          <PrimaryButton
            label="ENTER THE ATELIER"
            onPress={doLogin}
            style={styles.enter}
          />
        </View>
      </View>
      <Text style={styles.footer}>PARIS · LONDON · NEW YORK</Text>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 34 },
  mono: {
    width: 70,
    height: 70,
    borderWidth: 1,
    borderColor: gold(0.45),
    borderRadius: 35,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 28,
  },
  monoMark: {
    fontFamily: fonts.serifItalic,
    fontSize: 30,
    color: colors.gold,
    letterSpacing: 1,
  },
  title: {
    fontFamily: fonts.serif,
    fontSize: 34,
    letterSpacing: 9,
    color: colors.creamBright,
  },
  tagline: {
    fontFamily: fonts.serifItalic,
    fontSize: 18,
    color: gold(0.75),
    letterSpacing: 1.5,
    marginTop: 8,
  },
  form: {
    width: 280,
    marginTop: 46,
    gap: 14,
  },
  input: {
    borderBottomWidth: 1,
    borderBottomColor: gold(0.28),
    color: colors.cream,
    fontSize: 14,
    paddingVertical: 11,
    paddingHorizontal: 2,
    letterSpacing: 0.3,
    fontFamily: fonts.sans,
  },
  enter: {
    marginTop: 26,
    justifyContent: 'center',
    paddingVertical: 14,
  },
  footer: {
    position: 'absolute',
    bottom: 34,
    alignSelf: 'center',
    fontSize: 11,
    color: cream(0.32),
    letterSpacing: 2,
    fontFamily: fonts.sans,
  },
});
