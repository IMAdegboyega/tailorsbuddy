import React from 'react';
import { Modal, Pressable, StyleSheet, Text, View } from 'react-native';

import { colors, cream, fonts, gold } from '../theme';
import { Field } from '../components/ui';
import { useApp } from '../state/AppContext';

export function NewClientModal() {
  const { showNewClient, ncName, ncContact, setNcName, setNcContact, addClient, cancelNewClient } =
    useApp();

  return (
    <Modal visible={showNewClient} transparent animationType="fade" onRequestClose={cancelNewClient}>
      <Pressable style={styles.backdrop} onPress={cancelNewClient}>
        <Pressable style={styles.card} onPress={() => {}}>
          <Text style={styles.title}>New Client</Text>
          <Text style={styles.subtitle}>Add a name to the atelier book.</Text>
          <View style={styles.form}>
            <Field
              label="Full name"
              value={ncName}
              onChangeText={setNcName}
              placeholder="e.g. Ottoline Ferrers"
            />
            <Field
              label="Contact"
              value={ncContact}
              onChangeText={setNcContact}
              placeholder="email or phone"
            />
          </View>
          <View style={styles.actions}>
            <Pressable
              onPress={cancelNewClient}
              style={({ pressed }) => [styles.cancel, pressed && { borderColor: gold(0.5) }]}
            >
              <Text style={styles.cancelLabel}>CANCEL</Text>
            </Pressable>
            <Pressable
              onPress={addClient}
              style={({ pressed }) => [styles.add, { backgroundColor: pressed ? colors.goldBright : colors.gold }]}
            >
              <Text style={styles.addLabel}>ADD CLIENT</Text>
            </Pressable>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(4,4,6,0.72)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  card: {
    width: 360,
    maxWidth: '100%',
    backgroundColor: colors.bgCard,
    borderWidth: 1,
    borderColor: gold(0.28),
    borderRadius: 5,
    padding: 30,
  },
  title: { fontFamily: fonts.serif, fontSize: 24, color: colors.creamBright, marginBottom: 4 },
  subtitle: { fontFamily: fonts.serifItalic, fontSize: 15, color: gold(0.7), marginBottom: 24 },
  form: { gap: 18 },
  actions: { flexDirection: 'row', gap: 12, marginTop: 30 },
  cancel: {
    flex: 1,
    borderWidth: 1,
    borderColor: gold(0.28),
    paddingVertical: 12,
    borderRadius: 2,
    alignItems: 'center',
  },
  cancelLabel: { color: cream(0.7), fontSize: 11, letterSpacing: 2, fontFamily: fonts.sans },
  add: { flex: 1, paddingVertical: 12, borderRadius: 2, alignItems: 'center' },
  addLabel: { color: colors.bg, fontSize: 11, letterSpacing: 2, fontFamily: fonts.sansSemiBold },
});
