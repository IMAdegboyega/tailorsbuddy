import React from 'react';
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Ellipse, Path } from 'react-native-svg';

import { colors, cream, fonts, gold } from '../theme';
import { DPATHS, FIELDS, initials } from '../data';
import { Icon } from '../components/Icon';
import { BackLink, PrimaryButton } from '../components/ui';
import { useApp } from '../state/AppContext';

/** Cream croquis-card thumbnail for a saved design. */
function DesignThumb({ pathIndex }: { pathIndex: number }) {
  return (
    <LinearGradient colors={[colors.sketchLight, colors.sketchDark]} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={styles.thumbFill}>
      <Svg viewBox="0 0 120 160" width="100%" height="100%">
        <Ellipse cx={60} cy={20} rx={8} ry={10} fill="none" stroke="#9a9088" strokeWidth={0.8} opacity={0.9} />
        <Path d={DPATHS[pathIndex]} fill="#dfd6c6" stroke="#9a9088" strokeWidth={0.8} opacity={0.9} />
      </Svg>
    </LinearGradient>
  );
}

export function ClientDetailScreen() {
  const {
    active,
    goClients,
    startNewDesign,
    detailTab,
    setDetailTab,
    meas,
    setMeas,
    showToast,
  } = useApp();
  const client = active();
  const { width } = useWindowDimensions();

  // Available content width (screen minus rail ~78 minus horizontal padding ~80).
  const avail = Math.max(240, width - 78 - 80);
  const designCols = Math.max(2, Math.min(4, Math.floor(avail / 165)));
  const measCols = avail > 460 ? 2 : 1;

  return (
    <View style={styles.fill}>
      <View style={styles.header}>
        <BackLink label="ALL CLIENTS" onPress={goClients} />
        <View style={styles.headRow}>
          <View style={styles.headLeft}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>{initials(client.name)}</Text>
            </View>
            <View>
              <Text style={styles.name}>{client.name}</Text>
              <Text style={styles.contact}>{client.contact}</Text>
            </View>
          </View>
          <PrimaryButton label="NEW DESIGN" icon="plus" onPress={startNewDesign} />
        </View>
        <View style={styles.tabs}>
          <Tab label="Measurements" active={detailTab === 'meas'} onPress={() => setDetailTab('meas')} />
          <Tab label="Designs" active={detailTab === 'designs'} onPress={() => setDetailTab('designs')} />
        </View>
      </View>

      {detailTab === 'meas' ? (
        <ScrollView contentContainerStyle={styles.body} showsVerticalScrollIndicator={false}>
          <View style={styles.measHead}>
            <Text style={styles.measHint}>Recorded in inches</Text>
            <Text style={styles.updated}>LAST UPDATED · {client.updated}</Text>
          </View>
          <View style={styles.measGrid}>
            {FIELDS.map(([key, label]) => {
              const value = meas[key] != null ? meas[key] : client.m[key] ?? '—';
              return (
                <View key={key} style={[styles.measRow, { width: measCols === 2 ? '50%' : '100%' }]}>
                  <View style={styles.measRowInner}>
                    <Text style={styles.measLabel}>{label}</Text>
                    <View style={styles.measValueWrap}>
                      <TextInput
                        value={String(value ?? '')}
                        onChangeText={(v) => setMeas(key, v)}
                        keyboardType="decimal-pad"
                        selectionColor={colors.gold}
                        style={styles.measInput}
                      />
                      <Text style={styles.measUnit}>in</Text>
                    </View>
                  </View>
                </View>
              );
            })}
          </View>
        </ScrollView>
      ) : (
        <ScrollView contentContainerStyle={styles.body} showsVerticalScrollIndicator={false}>
          <View style={styles.designGrid}>
            <Pressable
              onPress={startNewDesign}
              style={({ pressed }) => [
                styles.newSketch,
                { width: `${100 / designCols}%` },
                pressed && { backgroundColor: gold(0.04) },
              ]}
            >
              <View style={styles.newSketchInner}>
                <Icon name="plus" size={26} color={gold(0.7)} strokeWidth={1.3} />
                <Text style={styles.newSketchLabel}>NEW SKETCH</Text>
              </View>
            </Pressable>
            {client.designs.map((d, i) => (
              <Pressable
                key={i}
                onPress={() => showToast('Opening “' + d.title + '”')}
                style={[styles.designCell, { width: `${100 / designCols}%` }]}
              >
                <View style={styles.thumbWrap}>
                  <DesignThumb pathIndex={d.p} />
                  <View style={styles.garmentTag}>
                    <Text style={styles.garmentTagText}>{d.garment}</Text>
                  </View>
                </View>
                <Text style={styles.designTitle}>{d.title}</Text>
                <Text style={styles.designDate}>{d.date}</Text>
              </Pressable>
            ))}
          </View>
        </ScrollView>
      )}
    </View>
  );
}

function Tab({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={[styles.tab, active && styles.tabActive]}>
      <Text style={[styles.tabLabel, { color: active ? colors.creamBright : cream(0.4) }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
  header: { paddingTop: 26, paddingHorizontal: 40 },
  headRow: {
    marginTop: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headLeft: { flexDirection: 'row', alignItems: 'center', gap: 20 },
  avatar: {
    width: 62,
    height: 62,
    borderRadius: 31,
    backgroundColor: '#1c1810',
    borderWidth: 1,
    borderColor: gold(0.32),
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: { fontFamily: fonts.serif, fontSize: 24, color: colors.gold },
  name: { fontFamily: fonts.serif, fontSize: 32, color: colors.creamBright, lineHeight: 34 },
  contact: { fontSize: 12, color: cream(0.5), marginTop: 5, letterSpacing: 0.4, fontFamily: fonts.sans },
  tabs: {
    flexDirection: 'row',
    gap: 30,
    marginTop: 26,
    borderBottomWidth: 1,
    borderBottomColor: gold(0.16),
  },
  tab: { paddingBottom: 14, marginBottom: -1, borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabActive: { borderBottomColor: colors.gold },
  tabLabel: { fontFamily: fonts.serif, fontSize: 18 },
  body: { paddingHorizontal: 40, paddingTop: 24, paddingBottom: 40 },
  measHead: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  measHint: { fontFamily: fonts.serifItalic, fontSize: 19, color: gold(0.85) },
  updated: { fontSize: 11, color: cream(0.4), letterSpacing: 1, fontFamily: fonts.sans },
  measGrid: { flexDirection: 'row', flexWrap: 'wrap' },
  measRow: { paddingHorizontal: 0 },
  measRowInner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 13,
    marginHorizontal: 0,
    borderBottomWidth: 1,
    borderBottomColor: gold(0.1),
  },
  measLabel: { fontSize: 13, color: cream(0.7), letterSpacing: 0.3, fontFamily: fonts.sans },
  measValueWrap: { flexDirection: 'row', alignItems: 'baseline', gap: 4 },
  measInput: {
    width: 56,
    textAlign: 'right',
    borderBottomWidth: 1,
    borderBottomColor: gold(0.22),
    color: colors.creamBright,
    fontFamily: fonts.serif,
    fontSize: 20,
    paddingVertical: 2,
  },
  measUnit: { fontSize: 12, color: gold(0.55), fontFamily: fonts.sans },
  designGrid: { flexDirection: 'row', flexWrap: 'wrap', marginHorizontal: -10 },
  newSketch: { padding: 10 },
  newSketchInner: {
    aspectRatio: 3 / 4,
    borderWidth: 1,
    borderColor: gold(0.35),
    borderStyle: 'dashed',
    borderRadius: 3,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  newSketchLabel: { fontSize: 11, letterSpacing: 2, color: gold(0.7), fontFamily: fonts.sans },
  designCell: { padding: 10 },
  thumbWrap: {
    aspectRatio: 3 / 4,
    borderWidth: 1,
    borderColor: gold(0.16),
    borderRadius: 3,
    overflow: 'hidden',
    position: 'relative',
  },
  thumbFill: { flex: 1 },
  garmentTag: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: 'rgba(255,255,255,0.6)',
    paddingVertical: 2,
    paddingHorizontal: 6,
    borderRadius: 2,
  },
  garmentTagText: { fontSize: 9, letterSpacing: 1, color: '#8a7a55', fontFamily: fonts.sans },
  designTitle: { fontFamily: fonts.serif, fontSize: 15, color: colors.creamBright, marginTop: 9 },
  designDate: { fontSize: 11, color: cream(0.4), marginTop: 2, fontFamily: fonts.sans },
});
