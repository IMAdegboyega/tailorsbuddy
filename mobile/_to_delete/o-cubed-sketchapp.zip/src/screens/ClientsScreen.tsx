import React, { useMemo } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';

import { colors, cream, fonts, gold } from '../theme';
import { Icon } from '../components/Icon';
import { Kicker, OutlineButton } from '../components/ui';
import { initials, useApp } from '../state/AppContext';

export function ClientsScreen() {
  const { clients, search, setSearch, openClient, openNewClient } = useApp();

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return clients.filter((c) => c.name.toLowerCase().includes(q));
  }, [clients, search]);

  return (
    <View style={styles.fill}>
      <View style={styles.header}>
        <View>
          <Kicker style={{ marginBottom: 8 }}>THE CLIENTELE</Kicker>
          <Text style={styles.title}>Clients</Text>
        </View>
        <OutlineButton label="NEW CLIENT" icon="plus" onPress={openNewClient} />
      </View>

      <View style={styles.searchWrap}>
        <View style={styles.searchRow}>
          <Icon name="search" size={16} color={gold(0.6)} strokeWidth={1.5} />
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="Search by name…"
            placeholderTextColor={cream(0.32)}
            selectionColor={colors.gold}
            style={styles.searchInput}
          />
          <Text style={styles.count}>{filtered.length} CLIENTS</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.list} showsVerticalScrollIndicator={false}>
        {filtered.map((c) => (
          <Pressable
            key={c.id}
            onPress={() => openClient(c.id)}
            style={({ pressed }) => [styles.row, pressed && { backgroundColor: gold(0.03) }]}
          >
            <View style={styles.rowAvatar}>
              <Text style={styles.rowAvatarText}>{initials(c.name)}</Text>
            </View>
            <View style={styles.rowMid}>
              <Text style={styles.rowName}>{c.name}</Text>
              <Text style={styles.rowSub}>
                {c.designs.length} design{c.designs.length === 1 ? '' : 's'} ·{' '}
                {c.contact.split('·')[0].trim()}
              </Text>
            </View>
            <View style={styles.rowRight}>
              <Text style={styles.rowRightLabel}>LAST DESIGN</Text>
              <Text style={styles.rowRightValue}>{c.lastDesign}</Text>
            </View>
            <Icon name="chevronRight" size={16} color={gold(0.5)} strokeWidth={1.4} />
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
  header: {
    paddingTop: 34,
    paddingHorizontal: 40,
    paddingBottom: 20,
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  title: {
    fontFamily: fonts.serif,
    fontSize: 38,
    color: colors.creamBright,
  },
  searchWrap: { paddingHorizontal: 40, paddingBottom: 18 },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    borderBottomWidth: 1,
    borderBottomColor: gold(0.18),
    paddingBottom: 10,
  },
  searchInput: {
    flex: 1,
    color: colors.cream,
    fontSize: 14,
    letterSpacing: 0.3,
    fontFamily: fonts.sans,
    padding: 0,
  },
  count: {
    fontSize: 11,
    color: cream(0.4),
    letterSpacing: 1,
    fontFamily: fonts.sans,
  },
  list: { paddingHorizontal: 40, paddingTop: 4, paddingBottom: 34 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 18,
    paddingVertical: 18,
    paddingHorizontal: 6,
    borderBottomWidth: 1,
    borderBottomColor: gold(0.1),
  },
  rowAvatar: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: '#1c1810',
    borderWidth: 1,
    borderColor: gold(0.3),
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowAvatarText: { fontFamily: fonts.serif, fontSize: 18, color: colors.gold },
  rowMid: { flex: 1, minWidth: 0 },
  rowName: { fontFamily: fonts.serif, fontSize: 20, color: colors.creamBright },
  rowSub: { fontSize: 12, color: cream(0.45), marginTop: 3, letterSpacing: 0.3, fontFamily: fonts.sans },
  rowRight: { alignItems: 'flex-end' },
  rowRightLabel: { fontSize: 10, letterSpacing: 2, color: gold(0.6), fontFamily: fonts.sans },
  rowRightValue: { fontFamily: fonts.serif, fontSize: 16, color: colors.cream, marginTop: 2 },
});
