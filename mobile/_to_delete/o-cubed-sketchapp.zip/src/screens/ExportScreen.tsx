import React, { useMemo } from 'react';
import { Image, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

import { colors, cream, fonts, gold } from '../theme';
import { FIELDS, GarmentName, MeasKey, TEMPLATES, todayLabel } from '../data';
import { Icon } from '../components/Icon';
import { OutlineButton, PrimaryButton } from '../components/ui';
import { useApp } from '../state/AppContext';

const CANVAS_RATIO = 620 / 700;

export function ExportScreen() {
  const { active, garment, meas, usedList, designImage, backToCanvas, saveImageToast, sendToClient } =
    useAppExport();
  const client = active();

  const specKeys: MeasKey[] = useMemo(() => {
    if (garment) return TEMPLATES[garment];
    const firstGarment = client.designs[0]?.garment;
    const match = (Object.keys(TEMPLATES) as GarmentName[]).find(
      (g) => g.toUpperCase() === firstGarment
    );
    return match ? TEMPLATES[match] : FIELDS.slice(0, 8).map((f) => f[0]);
  }, [garment, client]);

  const specRows = FIELDS.filter(([k]) => specKeys.includes(k)).map(([k, label]) => ({
    label,
    value: (meas[k] != null ? meas[k] : client.m[k] ?? '—') + '"',
  }));

  const fabricNote = usedList.length
    ? 'Rendered in ' +
      usedList.map((u) => u.name.toLowerCase()).join(', ') +
      '. Hand-finished seams, couture lining throughout. Fittings to confirm drape before final cut.'
    : 'Fabric to be confirmed at first fitting. Hand-finished seams and couture lining throughout.';

  const specRef = 'OC-' + String(client.id).padStart(3, '0') + '-' + (client.designs.length + 1);
  const today = todayLabel();
  const garmentLabel = garment ?? '';

  return (
    <LinearGradient colors={['#131210', colors.bg]} style={styles.fill}>
      <View style={styles.topbar}>
        <Pressable onPress={backToCanvas} style={styles.back} hitSlop={8}>
          <Icon name="chevronLeft" size={14} color={gold(0.75)} strokeWidth={1.6} />
          <Text style={styles.backLabel}>BACK TO CANVAS</Text>
        </Pressable>
        <View style={styles.topActions}>
          <OutlineButton label="SAVE IMAGE" icon="download" onPress={saveImageToast} />
          <PrimaryButton label="SEND TO CLIENT" icon="send" onPress={sendToClient} />
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.body} showsVerticalScrollIndicator={false}>
        {/* shareable card */}
        <View style={styles.cardCol}>
          <Text style={styles.sectionLabel}>SHAREABLE CARD</Text>
          <View style={styles.card}>
            <LinearGradient colors={[colors.sketchLight, colors.sketchDark]} style={styles.cardImg}>
              {!!designImage && <Image source={{ uri: designImage }} style={styles.cardImage} resizeMode="contain" />}
            </LinearGradient>
            <View style={styles.cardMeta}>
              <Text style={styles.cardBrand}>O_Cubed</Text>
              <Text style={styles.cardTitle}>
                {garmentLabel} for {client.name}
              </Text>
              <View style={styles.rule} />
              <Text style={styles.cardDate}>{today}</Text>
            </View>
          </View>
        </View>

        {/* spec sheet */}
        <View style={styles.specCol}>
          <Text style={styles.sectionLabel}>SPEC SHEET</Text>
          <View style={styles.spec}>
            <View style={styles.specHead}>
              <View>
                <Text style={styles.specBrand}>O_CUBED</Text>
                <Text style={styles.specSub}>couture specification sheet</Text>
              </View>
              <View style={styles.specMono}>
                <Text style={styles.specMonoMark}>O³</Text>
              </View>
            </View>

            <View style={styles.specMain}>
              <LinearGradient colors={[colors.sketchLight, colors.sketchDark]} style={styles.specImg}>
                {!!designImage && <Image source={{ uri: designImage }} style={styles.specImage} resizeMode="contain" />}
              </LinearGradient>
              <View style={styles.specInfo}>
                <View style={styles.specNameRow}>
                  <Text style={styles.specName}>{client.name}</Text>
                  <Text style={styles.specGarment}>{garmentLabel}</Text>
                </View>
                <Text style={styles.specContact}>{client.contact}</Text>
                <Text style={styles.specMeasLabel}>MEASUREMENTS · IN</Text>
                <View style={styles.specGrid}>
                  {specRows.map((s) => (
                    <View key={s.label} style={styles.specRow}>
                      <Text style={styles.specRowLabel}>{s.label}</Text>
                      <Text style={styles.specRowValue}>{s.value}</Text>
                    </View>
                  ))}
                </View>
              </View>
            </View>

            <View style={styles.specNotes}>
              <Text style={styles.specMeasLabel}>FABRIC &amp; FINISH NOTES</Text>
              <View style={styles.fabricTags}>
                {usedList.map((u) => (
                  <View key={u.name} style={styles.fabricTag}>
                    <View style={[styles.fabricDot, { backgroundColor: u.dot }]} />
                    <Text style={styles.fabricTagText}>{u.name}</Text>
                  </View>
                ))}
              </View>
              <Text style={styles.fabricNote}>{fabricNote}</Text>
            </View>

            <View style={styles.specFooter}>
              <Text style={styles.specRef}>
                Ref · {specRef} · {today}
              </Text>
              <View>
                <View style={styles.signLine} />
                <Text style={styles.signLabel}>S. VAUX · MAÎTRE TAILLEUR</Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

/** Small adapter so this screen can bind the toast-driven actions to context. */
function useAppExport() {
  const ctx = useApp();
  return {
    ...ctx,
    saveImageToast: () => ctx.showToast('Design image saved'),
    sendToClient: () => ctx.showToast('Spec sheet sent to ' + ctx.active().name),
  };
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
  topbar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 18,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: gold(0.14),
    backgroundColor: 'rgba(8,8,10,0.9)',
    flexWrap: 'wrap',
    gap: 12,
  },
  back: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  backLabel: { color: gold(0.75), fontSize: 11, letterSpacing: 2, fontFamily: fonts.sans },
  topActions: { flexDirection: 'row', gap: 12 },
  body: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 30,
    padding: 34,
    paddingBottom: 50,
  },
  cardCol: { width: 300 },
  sectionLabel: { fontSize: 10, letterSpacing: 2, color: gold(0.6), marginBottom: 12, fontFamily: fonts.sans },
  card: {
    borderWidth: 1,
    borderColor: gold(0.25),
    borderRadius: 4,
    overflow: 'hidden',
    backgroundColor: colors.bgCard,
  },
  cardImg: { padding: 14, minHeight: 200, alignItems: 'center', justifyContent: 'center' },
  cardImage: { width: '100%', aspectRatio: CANVAS_RATIO, borderRadius: 2 },
  cardMeta: { padding: 20, paddingTop: 18, alignItems: 'center' },
  cardBrand: { fontFamily: fonts.serifItalic, fontSize: 15, color: colors.gold, letterSpacing: 1 },
  cardTitle: { fontFamily: fonts.serif, fontSize: 22, color: colors.creamBright, marginTop: 6, textAlign: 'center' },
  rule: { width: 36, height: 1, backgroundColor: gold(0.4), marginVertical: 12 },
  cardDate: { fontSize: 11, color: cream(0.5), letterSpacing: 0.5, fontFamily: fonts.sans },
  specCol: { width: 520, maxWidth: '100%' },
  spec: { backgroundColor: colors.bgCard, borderWidth: 1, borderColor: gold(0.25), borderRadius: 4, padding: 34 },
  specHead: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: gold(0.22),
    paddingBottom: 20,
  },
  specBrand: { fontFamily: fonts.serif, fontSize: 26, letterSpacing: 4, color: colors.creamBright },
  specSub: { fontFamily: fonts.serifItalic, fontSize: 15, color: gold(0.75), marginTop: 2 },
  specMono: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: gold(0.4),
    alignItems: 'center',
    justifyContent: 'center',
  },
  specMonoMark: { fontFamily: fonts.serifItalic, fontSize: 15, color: colors.gold },
  specMain: { flexDirection: 'row', gap: 26, marginTop: 24 },
  specImg: { width: 150, borderRadius: 2, padding: 8, minHeight: 170, alignItems: 'center', justifyContent: 'center' },
  specImage: { width: '100%', aspectRatio: CANVAS_RATIO },
  specInfo: { flex: 1, minWidth: 0 },
  specNameRow: { flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 4 },
  specName: { fontFamily: fonts.serif, fontSize: 20, color: colors.creamBright },
  specGarment: { fontSize: 11, letterSpacing: 1, color: gold(0.7), fontFamily: fonts.sans },
  specContact: { fontSize: 11, color: cream(0.45), marginBottom: 14, fontFamily: fonts.sans },
  specMeasLabel: { fontSize: 10, letterSpacing: 2, color: gold(0.7), marginBottom: 8, fontFamily: fonts.sans },
  specGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  specRow: {
    width: '46%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 5,
    borderBottomWidth: 1,
    borderBottomColor: gold(0.1),
  },
  specRowLabel: { fontSize: 11, color: cream(0.6), fontFamily: fonts.sans },
  specRowValue: { fontFamily: fonts.serif, fontSize: 15, color: colors.creamBright },
  specNotes: { marginTop: 22, borderTopWidth: 1, borderTopColor: gold(0.18), paddingTop: 16 },
  fabricTags: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 10 },
  fabricTag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    borderWidth: 1,
    borderColor: gold(0.28),
    borderRadius: 20,
    paddingVertical: 5,
    paddingLeft: 6,
    paddingRight: 12,
  },
  fabricDot: { width: 12, height: 12, borderRadius: 6, borderWidth: 1, borderColor: gold(0.4) },
  fabricTagText: { fontSize: 11, color: cream(0.75), fontFamily: fonts.sans },
  fabricNote: { fontFamily: fonts.serif, fontSize: 15, lineHeight: 22, color: cream(0.55) },
  specFooter: { marginTop: 22, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  specRef: { fontSize: 10, letterSpacing: 1, color: cream(0.35), fontFamily: fonts.sans },
  signLine: { width: 120, borderBottomWidth: 1, borderBottomColor: gold(0.35), marginBottom: 5 },
  signLabel: { fontSize: 10, letterSpacing: 1, color: gold(0.65), fontFamily: fonts.sans, textAlign: 'right' },
});
