import React, { useMemo, useRef, useState } from 'react';
import {
  LayoutChangeEvent,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import { Canvas, Image as SkiaImage } from '@shopify/react-native-skia';
import { LinearGradient } from 'expo-linear-gradient';

import { colors, cream, fonts, gold } from '../theme';
import { COLORS, FABRICS, Fabric, INKS, WEIGHTS } from '../data';
import { Icon, IconName } from '../components/Icon';
import { PrimaryButton } from '../components/ui';
import { Tool, useApp } from '../state/AppContext';
import { CANVAS_H, CANVAS_W, SketchEngine } from '../canvas/engine';
import { FillFn, fabricFill, hexRgb, solidFill } from '../canvas/fills';
import { makeCroquisImage } from '../canvas/croquis';

// Approximate RN gradients for the fabric chips (prototype uses CSS gradients).
const FABRIC_CHIP: Record<string, string[]> = {
  silk: ['#d9c7a3', '#f0e6cf', '#c9b489'],
  satin: ['#20202a', '#4a4a58', '#1a1a22'],
  lace: ['#efe9dd', '#e3dccb', '#cfc7b4'],
  denim: ['#38507a', '#2e4060', '#243350'],
  velvet: ['#7a2a40', '#5a1d30', '#4a1526'],
  tulle: ['#f0d9d6', '#e3c3c0', '#d9b3af'],
};

export function CanvasScreen() {
  const {
    active,
    garment,
    backToDetail,
    exportDesign,
    tool,
    setTool,
    ink,
    setInk,
    weight,
    setWeight,
    view,
    setView,
    fabric,
    setFabric,
    markFabric,
  } = useApp();
  const client = active();
  const { width } = useWindowDimensions();

  const engineRef = useRef<SketchEngine | null>(null);
  if (!engineRef.current) engineRef.current = new SketchEngine();
  const engine = engineRef.current;

  const [, force] = useState(0);
  const bump = () => force((v) => v + 1);

  // Live refs so gesture closures always read the latest tool state.
  const fillRef = useRef<FillFn | null>(null);
  const usedRef = useRef<{ name: string; dot: string } | null>(null);
  const stateRef = useRef({ tool, ink, weight, view });
  stateRef.current = { tool, ink, weight, view };
  const drawing = useRef(false);
  const last = useRef({ x: 0, y: 0 });

  // Canvas area measurement → scale the 620x700 logical surface to fit.
  const [area, setArea] = useState({ w: 0, h: 0 });
  const onArea = (e: LayoutChangeEvent) =>
    setArea({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height });
  const scale = Math.min(
    area.w > 0 ? (area.w - 24) / CANVAS_W : 1,
    area.h > 0 ? (area.h - 60) / CANVAS_H : 1,
    1
  );
  const dispW = Math.max(120, CANVAS_W * (scale > 0 ? scale : 0.3));
  const dispH = Math.max(135, CANVAS_H * (scale > 0 ? scale : 0.3));
  const s = dispW / CANVAS_W;

  const bgImage = useMemo(() => makeCroquisImage(CANVAS_W, CANVAS_H, view), [view]);
  const inkImage = engine.inkImage(view);

  const panelW = Math.min(230, Math.max(150, width * 0.3));

  const toSurface = (x: number, y: number) => ({ x: x / s, y: y / s });

  const pan = useMemo(
    () =>
      Gesture.Pan()
        .runOnJS(true)
        .maxPointers(1)
        .onBegin((e) => {
          const { tool: t, view: v, ink: k, weight: w } = stateRef.current;
          const p = toSurface(e.x, e.y);
          if (t === 'fill') {
            if (fillRef.current) {
              engine.snapshot(v);
              const ok = engine.fill(v, p.x, p.y, fillRef.current);
              if (ok && usedRef.current) markFabric(usedRef.current);
              bump();
            }
            return;
          }
          engine.snapshot(v);
          drawing.current = true;
          last.current = p;
          engine.segment(v, p.x, p.y, p.x, p.y, k, w, t === 'eraser');
          bump();
        })
        .onUpdate((e) => {
          if (!drawing.current) return;
          const { tool: t, view: v, ink: k, weight: w } = stateRef.current;
          const p = toSurface(e.x, e.y);
          engine.segment(v, last.current.x, last.current.y, p.x, p.y, k, w, t === 'eraser');
          last.current = p;
          bump();
        })
        .onFinalize(() => {
          drawing.current = false;
        }),
    // recreate when scale changes so toSurface uses current scale
    [s]
  );

  const chooseColor = (name: string, v: string) => {
    fillRef.current = solidFill(hexRgb(v));
    usedRef.current = { name, dot: v };
    setFabric('c' + name);
    setTool('fill');
  };
  const chooseFabric = (f: Fabric) => {
    fillRef.current = fabricFill(f);
    usedRef.current = { name: f.name, dot: FABRIC_CHIP[f.id]?.[1] ?? '#BE8A5A' };
    setFabric(f.id);
    setTool('fill');
  };

  const doExport = () => {
    const img = engine.capture(view);
    exportDesign(img);
  };

  const hint =
    tool === 'fill'
      ? 'Tap inside a closed shape to fill it'
      : tool === 'eraser'
      ? 'Erasing'
      : 'Sketch the garment over the croquis';

  return (
    <View style={styles.fill}>
      {/* top bar */}
      <View style={styles.topbar}>
        <View style={styles.topLeft}>
          <Pressable onPress={backToDetail} hitSlop={8} style={styles.topBack}>
            <Icon name="chevronLeft" size={15} color={gold(0.7)} strokeWidth={1.6} />
          </Pressable>
          <View style={styles.topDivider} />
          <View>
            <Text style={styles.topKicker}>DESIGNING FOR</Text>
            <Text style={styles.topClient}>
              {client.name} · <Text style={styles.topGarment}>{garment}</Text>
            </Text>
          </View>
        </View>
        <PrimaryButton label="EXPORT" icon="upload" onPress={doExport} style={{ paddingVertical: 11 }} />
      </View>

      {/* body */}
      <View style={styles.body}>
        {/* tool rail */}
        <View style={styles.toolRail}>
          <ToolBtn icon="pencil" active={tool === 'pencil'} onPress={() => setTool('pencil')} />
          <ToolBtn icon="eraser" active={tool === 'eraser'} onPress={() => setTool('eraser')} />
          <View style={styles.railDivider} />
          {WEIGHTS.map((w) => (
            <Pressable
              key={w}
              onPress={() => setWeight(w)}
              style={[styles.weightBtn, weight === w && { backgroundColor: gold(0.14) }]}
            >
              <View
                style={{
                  width: w * 2 + 2,
                  height: w * 2 + 2,
                  borderRadius: (w * 2 + 2) / 2,
                  backgroundColor: weight === w ? colors.goldBright : gold(0.6),
                }}
              />
            </Pressable>
          ))}
          <View style={styles.railDivider} />
          <ToolBtn icon="undo" onPress={() => { engine.undo(view); bump(); }} muted />
          <ToolBtn icon="redo" onPress={() => { engine.redo(view); bump(); }} muted />
          <View style={{ flex: 1 }} />
          <ToolBtn icon="trash" onPress={() => { engine.clear(view); bump(); }} muted />
        </View>

        {/* canvas area */}
        <View style={styles.canvasArea} onLayout={onArea}>
          <View style={styles.toggle}>
            <Pressable onPress={() => setView('front')} style={[styles.toggleBtn, view === 'front' && styles.toggleOn]}>
              <Text style={[styles.toggleLabel, { color: view === 'front' ? colors.bg : gold(0.8) }]}>FRONT</Text>
            </Pressable>
            <Pressable onPress={() => setView('back')} style={[styles.toggleBtn, view === 'back' && styles.toggleOn]}>
              <Text style={[styles.toggleLabel, { color: view === 'back' ? colors.bg : gold(0.8) }]}>BACK</Text>
            </Pressable>
          </View>

          <GestureDetector gesture={pan}>
            <View style={[styles.canvasFrame, { width: dispW, height: dispH }]}>
              <Canvas style={{ width: dispW, height: dispH }}>
                {bgImage && <SkiaImage image={bgImage} x={0} y={0} width={dispW} height={dispH} fit="fill" />}
                {inkImage && <SkiaImage image={inkImage} x={0} y={0} width={dispW} height={dispH} fit="fill" />}
              </Canvas>
            </View>
          </GestureDetector>

          <Text style={styles.hint}>{hint}</Text>
        </View>

        {/* fabric & colour panel */}
        <ScrollView style={[styles.panel, { width: panelW }]} contentContainerStyle={styles.panelInner} showsVerticalScrollIndicator={false}>
          <Text style={styles.panelLabel}>INK</Text>
          <View style={styles.inkRow}>
            {INKS.map((v) => (
              <Pressable
                key={v}
                onPress={() => setInk(v)}
                style={[
                  styles.inkBtn,
                  { backgroundColor: v, borderColor: ink === v && tool !== 'fill' ? colors.goldBright : gold(0.25) },
                ]}
              />
            ))}
          </View>

          <Text style={styles.panelLabel}>COLOURS</Text>
          <View style={styles.colorGrid}>
            {COLORS.map((c) => {
              const on = fabric === 'c' + c.name;
              return (
                <Pressable
                  key={c.name}
                  onPress={() => chooseColor(c.name, c.v)}
                  style={[styles.colorChip, { backgroundColor: c.v, borderColor: on ? colors.goldBright : gold(0.22) }]}
                />
              );
            })}
          </View>

          <Text style={styles.panelLabel}>FABRICS</Text>
          <View style={styles.fabricGrid}>
            {FABRICS.map((f) => {
              const on = fabric === f.id;
              return (
                <Pressable key={f.id} onPress={() => chooseFabric(f)} style={styles.fabricCell}>
                  <LinearGradient
                    colors={FABRIC_CHIP[f.id] as [string, string, ...string[]]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={[styles.fabricChip, { borderColor: on ? colors.goldBright : gold(0.22) }]}
                  />
                  <Text style={[styles.fabricName, { color: on ? colors.goldBright : cream(0.6) }]}>{f.name}</Text>
                </Pressable>
              );
            })}
          </View>

          <View style={styles.tip}>
            <Text style={styles.tipText}>
              <Text style={{ color: colors.gold }}>Tip · </Text>
              Draw a closed outline, choose a colour or fabric, then tap inside to fill it.
            </Text>
          </View>
        </ScrollView>
      </View>
    </View>
  );
}

function ToolBtn({
  icon,
  active,
  muted,
  onPress,
}: {
  icon: IconName;
  active?: boolean;
  muted?: boolean;
  onPress: () => void;
}) {
  const color = active ? colors.goldBright : muted ? gold(0.6) : gold(0.7);
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.toolBtn,
        active && { backgroundColor: gold(0.14) },
        pressed && !active && { backgroundColor: gold(0.1) },
      ]}
    >
      <Icon name={icon} size={20} color={color} strokeWidth={1.5} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1, backgroundColor: colors.bg },
  topbar: {
    height: 60,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: gold(0.14),
    backgroundColor: colors.bgRail,
  },
  topLeft: { flexDirection: 'row', alignItems: 'center', gap: 16, flexShrink: 1 },
  topBack: { flexDirection: 'row', alignItems: 'center' },
  topDivider: { width: 1, height: 22, backgroundColor: gold(0.18) },
  topKicker: { fontSize: 10, letterSpacing: 2, color: gold(0.6), fontFamily: fonts.sans },
  topClient: { fontFamily: fonts.serif, fontSize: 17, color: colors.creamBright, lineHeight: 19 },
  topGarment: { fontFamily: fonts.serifItalic, color: colors.gold },
  body: { flex: 1, flexDirection: 'row', minHeight: 0 },
  toolRail: {
    width: 56,
    backgroundColor: colors.bgRail,
    borderRightWidth: 1,
    borderRightColor: gold(0.14),
    alignItems: 'center',
    paddingVertical: 16,
    gap: 6,
  },
  toolBtn: { width: 40, height: 40, borderRadius: 4, alignItems: 'center', justifyContent: 'center' },
  railDivider: { width: 30, height: 1, backgroundColor: gold(0.14), marginVertical: 6 },
  weightBtn: { width: 40, height: 24, borderRadius: 4, alignItems: 'center', justifyContent: 'center' },
  canvasArea: {
    flex: 1,
    minWidth: 0,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.bgCanvas,
    position: 'relative',
  },
  toggle: {
    position: 'absolute',
    top: 16,
    flexDirection: 'row',
    backgroundColor: colors.bgRail,
    borderWidth: 1,
    borderColor: gold(0.2),
    borderRadius: 3,
    overflow: 'hidden',
    zIndex: 2,
  },
  toggleBtn: { paddingVertical: 8, paddingHorizontal: 18 },
  toggleOn: { backgroundColor: colors.gold },
  toggleLabel: { fontSize: 10, letterSpacing: 2, fontFamily: fonts.sansSemiBold },
  canvasFrame: { borderRadius: 2, overflow: 'hidden', backgroundColor: '#faf7f0' },
  hint: { position: 'absolute', bottom: 14, fontSize: 11, letterSpacing: 1, color: cream(0.35), fontFamily: fonts.sans },
  panel: {
    backgroundColor: colors.bgRail,
    borderLeftWidth: 1,
    borderLeftColor: gold(0.14),
  },
  panelInner: { padding: 16 },
  panelLabel: { fontSize: 10, letterSpacing: 2, color: gold(0.7), marginBottom: 10, marginTop: 4, fontFamily: fonts.sans },
  inkRow: { flexDirection: 'row', gap: 8, marginBottom: 20 },
  inkBtn: { width: 26, height: 26, borderRadius: 13, borderWidth: 2 },
  colorGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 9, marginBottom: 22 },
  colorChip: { width: 32, height: 32, borderRadius: 3, borderWidth: 1 },
  fabricGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  fabricCell: { width: '46%' },
  fabricChip: { aspectRatio: 1.4, borderRadius: 3, borderWidth: 1 },
  fabricName: { fontSize: 10, letterSpacing: 0.5, marginTop: 5, textAlign: 'center', fontFamily: fonts.sans },
  tip: {
    marginTop: 22,
    padding: 12,
    borderWidth: 1,
    borderColor: gold(0.14),
    borderRadius: 3,
  },
  tipText: { fontSize: 11, lineHeight: 17, color: cream(0.5), fontFamily: fonts.sans },
});
