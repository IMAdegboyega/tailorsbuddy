import React, { useCallback } from 'react';
import { StyleSheet, View } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import {
  useFonts,
  CormorantGaramond_400Regular,
  CormorantGaramond_500Medium,
  CormorantGaramond_500Medium_Italic,
  CormorantGaramond_600SemiBold,
} from '@expo-google-fonts/cormorant-garamond';
import {
  Jost_300Light,
  Jost_400Regular,
  Jost_500Medium,
  Jost_600SemiBold,
} from '@expo-google-fonts/jost';

import { colors } from './src/theme';
import { AppProvider, useApp } from './src/state/AppContext';
import { Rail } from './src/components/Rail';
import { Toast } from './src/components/Toast';
import { LoginScreen } from './src/screens/LoginScreen';
import { ClientsScreen } from './src/screens/ClientsScreen';
import { ClientDetailScreen } from './src/screens/ClientDetailScreen';
import { NewDesignScreen } from './src/screens/NewDesignScreen';
import { CanvasScreen } from './src/screens/CanvasScreen';
import { CanvasBoundary } from './src/components/CanvasBoundary';
import { ExportScreen } from './src/screens/ExportScreen';
import { PricingScreen } from './src/screens/PricingScreen';
import { SettingsScreen } from './src/screens/SettingsScreen';
import { NewClientModal } from './src/screens/NewClientModal';

SplashScreen.preventAutoHideAsync().catch(() => {});

/** The persistent shell (rail + a shell screen) shared by the client / plans / settings surfaces. */
function Shell() {
  const { screen } = useApp();
  return (
    <View style={styles.shell}>
      <Rail />
      <View style={styles.main}>
        {screen === 'clients' && <ClientsScreen />}
        {screen === 'detail' && <ClientDetailScreen />}
        {screen === 'newdesign' && <NewDesignScreen />}
        {screen === 'pricing' && <PricingScreen />}
        {screen === 'settings' && <SettingsScreen />}
      </View>
    </View>
  );
}

function Router() {
  const { screen } = useApp();

  const isFull = screen === 'login' || screen === 'canvas' || screen === 'export';

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom', 'left', 'right']}>
      {screen === 'login' && <LoginScreen />}
      {screen === 'canvas' && (
        <CanvasBoundary>
          <CanvasScreen />
        </CanvasBoundary>
      )}
      {screen === 'export' && <ExportScreen />}
      {!isFull && <Shell />}
      <NewClientModal />
      <Toast />
    </SafeAreaView>
  );
}

export default function App() {
  const [fontsLoaded, fontError] = useFonts({
    CormorantGaramond_400Regular,
    CormorantGaramond_500Medium,
    CormorantGaramond_500Medium_Italic,
    CormorantGaramond_600SemiBold,
    Jost_300Light,
    Jost_400Regular,
    Jost_500Medium,
    Jost_600SemiBold,
  });

  const onLayout = useCallback(async () => {
    if (fontsLoaded || fontError) {
      await SplashScreen.hideAsync().catch(() => {});
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return (
    <GestureHandlerRootView style={styles.root} onLayout={onLayout}>
      <SafeAreaProvider>
        <StatusBar style="light" />
        <AppProvider>
          <Router />
        </AppProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.black },
  safe: { flex: 1, backgroundColor: colors.bg },
  shell: { flex: 1, flexDirection: 'row' },
  main: { flex: 1, minWidth: 0, position: 'relative' },
});
