import React, { createContext, useCallback, useContext, useMemo, useRef, useState } from 'react';

import {
  CLIENTS,
  Client,
  FIELDS,
  GarmentName,
  Measurements,
  initials,
} from '../data';

export type Screen =
  | 'login'
  | 'clients'
  | 'detail'
  | 'newdesign'
  | 'canvas'
  | 'export'
  | 'pricing'
  | 'settings';

export type DetailTab = 'meas' | 'designs';
export type Tool = 'pencil' | 'eraser' | 'fill';
export type Figure = 'female' | 'male';

/** A fabric/colour that has been applied on the canvas, for the spec sheet. */
export interface UsedFill {
  name: string;
  dot: string; // solid colour used to render the swatch dot
}

interface AppState {
  screen: Screen;
  clients: Client[];
  activeId: number;
  detailTab: DetailTab;
  search: string;
  showNewClient: boolean;
  ncName: string;
  ncContact: string;
  garment: GarmentName | null;
  // canvas
  tool: Tool;
  ink: string;
  weight: number;
  view: 'front' | 'back';
  figure: Figure;
  fabric: string | null;
  usedList: UsedFill[];
  designImage: string; // captured PNG data-uri
  toast: string;
  // per-client working measurements (overrides client.m while editing)
  meas: Measurements;
}

interface AppActions {
  active: () => Client;
  goClients: () => void;
  goPricing: () => void;
  goSettings: () => void;
  doLogin: () => void;
  openClient: (id: number) => void;
  startNewDesign: () => void;
  backToDetail: () => void;
  pickGarment: (g: GarmentName) => void;
  toCanvas: () => void;
  exportDesign: (image: string) => void;
  backToCanvas: () => void;
  setSearch: (v: string) => void;
  openNewClient: () => void;
  cancelNewClient: () => void;
  setNcName: (v: string) => void;
  setNcContact: (v: string) => void;
  addClient: () => void;
  setDetailTab: (t: DetailTab) => void;
  setMeas: (key: string, value: string) => void;
  showToast: (t: string) => void;
  // canvas setters
  setTool: (t: Tool) => void;
  setInk: (v: string) => void;
  setWeight: (w: number) => void;
  setView: (v: 'front' | 'back') => void;
  setFigure: (f: Figure) => void;
  setFabric: (id: string | null) => void;
  markFabric: (f: UsedFill) => void;
  resetCanvasFills: () => void;
}

type Ctx = AppState & AppActions;

const AppContext = createContext<Ctx | null>(null);

let nextId = Math.max(...CLIENTS.map((c) => c.id)) + 1;

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [clients, setClients] = useState<Client[]>(CLIENTS);
  const [screen, setScreen] = useState<Screen>('login');
  const [activeId, setActiveId] = useState<number>(1);
  const [detailTab, setDetailTab] = useState<DetailTab>('meas');
  const [search, setSearch] = useState('');
  const [showNewClient, setShowNewClient] = useState(false);
  const [ncName, setNcName] = useState('');
  const [ncContact, setNcContact] = useState('');
  const [garment, setGarment] = useState<GarmentName | null>(null);
  const [tool, setTool] = useState<Tool>('pencil');
  const [ink, setInkState] = useState('#33322c');
  const [weight, setWeightState] = useState(4);
  const [view, setViewState] = useState<'front' | 'back'>('front');
  const [figure, setFigure] = useState<Figure>('female');
  const [fabric, setFabric] = useState<string | null>(null);
  const [usedList, setUsedList] = useState<UsedFill[]>([]);
  const [designImage, setDesignImage] = useState('');
  const [toast, setToast] = useState('');
  const [meas, setMeasState] = useState<Measurements>({});

  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const active = useCallback(
    () => clients.find((c) => c.id === activeId) ?? clients[0],
    [clients, activeId]
  );

  const showToast = useCallback((t: string) => {
    setToast(t);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 2600);
  }, []);

  const openClient = useCallback(
    (id: number) => {
      const c = clients.find((x) => x.id === id);
      setActiveId(id);
      setDetailTab('meas');
      setMeasState(c ? { ...c.m } : {});
      setScreen('detail');
    },
    [clients]
  );

  const addClient = useCallback(() => {
    const name = (ncName || 'New Client').trim();
    const blank: Measurements = {};
    FIELDS.forEach(([k]) => (blank[k] = '—'));
    const client: Client = {
      id: nextId++,
      name,
      contact: ncContact || '—',
      lastDesign: '—',
      updated: 'today',
      m: blank,
      designs: [],
    };
    setClients((prev) => [client, ...prev]);
    setShowNewClient(false);
  }, [ncName, ncContact]);

  const setMeas = useCallback((key: string, value: string) => {
    setMeasState((prev) => ({ ...prev, [key]: value }));
  }, []);

  const toCanvas = useCallback(() => {
    setViewState('front');
    setFabric(null);
    setUsedList([]);
    setTool('pencil');
    setScreen('canvas');
  }, []);

  const markFabric = useCallback((f: UsedFill) => {
    setUsedList((prev) => (prev.find((u) => u.name === f.name) ? prev : [...prev, f]));
  }, []);

  const value = useMemo<Ctx>(
    () => ({
      // state
      screen,
      clients,
      activeId,
      detailTab,
      search,
      showNewClient,
      ncName,
      ncContact,
      garment,
      tool,
      ink,
      weight,
      view,
      figure,
      fabric,
      usedList,
      designImage,
      toast,
      meas,
      // actions
      active,
      goClients: () => setScreen('clients'),
      goPricing: () => setScreen('pricing'),
      goSettings: () => setScreen('settings'),
      doLogin: () => setScreen('clients'),
      openClient,
      startNewDesign: () => {
        setGarment(null);
        toCanvas();
      },
      backToDetail: () => setScreen('detail'),
      pickGarment: (g) => setGarment(g),
      toCanvas,
      exportDesign: (image: string) => {
        setDesignImage(image);
        setScreen('export');
      },
      backToCanvas: () => setScreen('canvas'),
      setSearch,
      openNewClient: () => {
        setNcName('');
        setNcContact('');
        setShowNewClient(true);
      },
      cancelNewClient: () => setShowNewClient(false),
      setNcName,
      setNcContact,
      addClient,
      setDetailTab,
      setMeas,
      showToast,
      setTool,
      setInk: (v: string) => {
        setInkState(v);
        setTool('pencil');
      },
      setWeight: (w: number) => {
        setWeightState(w);
        setTool('pencil');
      },
      setView: setViewState,
      setFigure,
      setFabric,
      markFabric,
      resetCanvasFills: () => setUsedList([]),
    }),
    [
      screen, clients, activeId, detailTab, search, showNewClient, ncName, ncContact,
      garment, tool, ink, weight, view, figure, fabric, usedList, designImage, toast, meas,
      active, openClient, toCanvas, addClient, setMeas, showToast, markFabric,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): Ctx {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within an AppProvider');
  return ctx;
}

export { initials };
