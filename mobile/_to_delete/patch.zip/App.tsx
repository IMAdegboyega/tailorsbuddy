import React, { Suspense, useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import {
  useFonts,
  CormorantGaramond_400Regular,
  CormorantGaramond_500Medium,
  CormorantGaramond_500Medium_Italic,
  CormorantGaramond_600SemiBold,
} from '@expo-google-fonts/cormorant-garamond';
import {
  Jost_300Light,
  Jost_400Regular,
  Jost_500Medium,
  Jost_600SemiBold,
} from '@expo-google-fonts/jost';

import { colors } from './src/theme';
import { AppProvider, useApp } from './src/state/AppContext';
import { Rail } from './src/components/Rail';
import { Toast } from './src/components/Toast';
import { LoginScreen } from './src/screens/LoginScreen';
import { ClientsScreen } from './src/screens/ClientsScreen';
import { ClientDetailScreen } from './src/screens/ClientDetailScreen';
import { CanvasBoundary } from './src/components/CanvasBoundary';
import { ExportScreen } from './src/screens/ExportScreen';
import { PricingScreen } from './src/screens/PricingScreen';
import { SettingsScreen } from './src/screens/SettingsScreen';
import { NewClientModal } from './src/screens/NewClientModal';

// The sketch canvas pulls in @shopify/react-native-skia (a native module). We
// load it lazily so Skia is only required when the canvas is opened — that keeps
// startup free of native modules that aren't present in Expo Go, so the app
// always boots. If Skia is unavailable, CanvasBoundary shows a graceful notice.
const CanvasScreen = React.lazy(() =>
  import('./src/screens/CanvasScreen').then((m) => ({ default: m.CanvasScreen }))
);

SplashScreen.preventAutoHideAsync().catch(() => {});

/** The persistent shell (rail + a shell screen) shared by the client / plans / settings surfaces. */
function Shell() {
  const { screen } = useApp();
  return (
    <View style={styles.shell}>
      <Rail />
      <View style={styles.main}>
        {screen === 'clients' && <ClientsScreen />}
        {screen === 'detail' && <ClientDetailScreen />}
        {screen === 'pricing' && <PricingScreen />}
        {screen === 'settings' && <SettingsScreen />}
      </View>
    </View>
  );
}

function CanvasFallback() {
  return (
    <View style={styles.canvasFallback}>
      <ActivityIndicator color={colors.gold} />
    </View>
  );
}

function Router() {
  const { screen } = useApp();

  const isFull = screen === 'login' || screen === 'canvas' || screen === 'export';

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom', 'left', 'right']}>
      {screen === 'login' && <LoginScreen />}
      {screen === 'canvas' && (
        <CanvasBoundary>
          <Suspense fallback={<CanvasFallback />}>
            <CanvasScreen />
          </Suspense>
        </CanvasBoundary>
      )}
      {screen === 'export' && <ExportScreen />}
      {!isFull && <Shell />}
      <NewClientModal />
      <Toast />
    </SafeAreaView>
  );
}

export default function App() {
  const [fontsLoaded, fontError] = useFonts({
    CormorantGaramond_400Regular,
    CormorantGaramond_500Medium,
    CormorantGaramond_500Medium_Italic,
    CormorantGaramond_600SemiBold,
    Jost_300Light,
    Jost_400Regular,
    Jost_500Medium,
    Jost_600SemiBold,
  });

  // Safety net: never let a slow/failed font load leave the app on the splash
  // screen forever — proceed after a short timeout regardless.
  const [timedOut, setTimedOut] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setTimedOut(true), 2500);
    return () => clearTimeout(t);
  }, []);

  const ready = fontsLoaded || !!fontError || timedOut;

  useEffect(() => {
    if (ready) SplashScreen.hideAsync().catch(() => {});
  }, [ready]);

  const onLayout = useCallback(async () => {
    if (ready) await SplashScreen.hideAsync().catch(() => {});
  }, [ready]);

  if (!ready) return null;

  return (
    <GestureHandlerRootView style={styles.root} onLayout={onLayout}>
      <SafeAreaProvider>
        <StatusBar style="light" />
        <AppProvider>
          <Router />
        </AppProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.black },
  safe: { flex: 1, backgroundColor: colors.bg },
  shell: { flex: 1, flexDirection: 'row' },
  main: { flex: 1, minWidth: 0, position: 'relative' },
  canvasFallback: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' },
});
